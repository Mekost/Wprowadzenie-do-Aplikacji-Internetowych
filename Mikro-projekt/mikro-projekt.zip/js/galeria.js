var modal = document.getElementById('myModal');

var img = document.getElementById('test');
var modalImg = document.getElementById("img01");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}

var span = document.getElementsByClassName("close")[0];

span.onclick = function() { 
  modal.style.display = "none";
}



var img2 = document.getElementById('test2');
var img3 = document.getElementById('test3');
var img4 = document.getElementById('test4');
var img5 = document.getElementById('test5');
var img6 = document.getElementById('test6');
var img7 = document.getElementById('test7');
var img8 = document.getElementById('test8');
var img9 = document.getElementById('test9');
var img10 = document.getElementById('test10');
var img11 = document.getElementById('test11');
var img12 = document.getElementById('test12');
var img13 = document.getElementById('test13');
var img14 = document.getElementById('test14');
var img15 = document.getElementById('test15');
var img16 = document.getElementById('test16');
var img17 = document.getElementById('test17');
var img18 = document.getElementById('test18');
var img19 = document.getElementById('test19');
var img20 = document.getElementById('test20');

img2.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img3.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img4.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img5.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img6.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img7.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img8.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img9.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img10.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img11.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img12.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img13.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img14.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img15.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img16.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img17.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img18.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img19.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}
img20.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}

